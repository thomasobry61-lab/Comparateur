package app.comparateur.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse

class OfferTest {
    private fun offer(
        merchant: String, price: Long, ship: Long? = null,
        freeOver: Long? = null, promo: Long = 0, stock: Boolean = true,
    ) = Offer(merchant, price, ship, freeOver, stock, "https://x/out/$merchant", null, promo)

    @Test fun `la livraison est ajoutee au prix`() {
        assertEquals(5_490, offer("A", 4_999, ship = 491).toPriced().totalCents)
    }

    @Test fun `livraison offerte au-dela du seuil`() {
        assertEquals(6_000, offer("A", 6_000, ship = 490, freeOver = 5_000).toPriced().totalCents)
    }

    @Test fun `le code promo baisse le total et peut declencher la livraison offerte`() {
        val p = offer("A", 5_500, ship = 490, freeOver = 5_000, promo = 400).toPriced()
        assertEquals(5_100, p.totalCents) // 5500 - 400, livraison offerte
    }

    @Test fun `classement par total et exclusion des ruptures`() {
        val ranked = listOf(
            offer("Cher", 4_000, ship = 1_500),
            offer("Malin", 4_300, ship = 0),
            offer("Rupture", 1_000, stock = false),
        ).rankByTotal()
        assertEquals(listOf("Malin", "Cher"), ranked.map { it.offer.merchant })
    }

    @Test fun `livraison inconnue est signalee`() {
        assertFalse(offer("A", 1_000).toPriced().shippingKnown)
    }
}
