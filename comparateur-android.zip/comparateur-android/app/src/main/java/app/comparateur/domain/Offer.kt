package app.comparateur.domain

import kotlinx.serialization.Serializable
import java.util.Locale

/** Montants en centimes (Long) : jamais de Double pour l'argent. */
@Serializable
data class Offer(
    val merchant: String,
    val priceCents: Long,
    val shippingCents: Long? = null,          // null = frais de port inconnus
    val freeShippingOverCents: Long? = null,  // seuil de livraison offerte
    val inStock: Boolean = true,
    val trackedUrl: String,                   // lien d'affiliation, via /out/{offre} côté serveur
    val promoCode: String? = null,
    val promoDiscountCents: Long = 0,
)

data class PricedOffer(
    val offer: Offer,
    val shippingCents: Long,
    val shippingKnown: Boolean,
    val totalCents: Long,
)

fun Offer.toPriced(): PricedOffer {
    val discounted = (priceCents - promoDiscountCents).coerceAtLeast(0)
    val freeShipping = freeShippingOverCents != null && discounted >= freeShippingOverCents
    val shipping = if (freeShipping) 0L else shippingCents ?: 0L
    return PricedOffer(
        offer = this,
        shippingCents = shipping,
        shippingKnown = freeShipping || shippingCents != null,
        totalCents = discounted + shipping,
    )
}

/**
 * Classement par prix total net uniquement. La commission d'affiliation
 * n'entre JAMAIS dans le tri (transparence exigée par la directive Omnibus).
 */
fun List<Offer>.rankByTotal(): List<PricedOffer> =
    filter { it.inStock }
        .map { it.toPriced() }
        .sortedWith(compareBy({ it.totalCents }, { !it.shippingKnown }))

fun Long.asEuros(): String = String.format(Locale.FRANCE, "%.2f €", this / 100.0)
