package app.comparateur

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.comparateur.data.ComparatorApi
import app.comparateur.ui.CompareScreen
import app.comparateur.ui.CompareViewModel

class MainActivity : ComponentActivity() {
    private val vm: CompareViewModel by viewModels {
        viewModelFactory { initializer { CompareViewModel(ComparatorApi.create(BuildConfig.API_URL)) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { CompareScreen(vm) } } }
    }
}
