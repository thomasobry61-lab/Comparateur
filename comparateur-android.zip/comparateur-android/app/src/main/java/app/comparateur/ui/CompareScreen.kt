package app.comparateur.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.comparateur.domain.PricedOffer
import app.comparateur.domain.asEuros

@Composable
fun CompareScreen(vm: CompareViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        BarcodeScanner(onBarcode = vm::onBarcode, modifier = Modifier.fillMaxWidth().height(200.dp))

        when (val s = state) {
            UiState.Idle -> Text(
                "Placez le code-barres d'un produit dans le cadre pour comparer les prix.",
                Modifier.padding(16.dp),
            )
            UiState.Loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
            is UiState.Error -> Text(s.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
            is UiState.Success -> LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item { Text(s.title, style = MaterialTheme.typography.titleLarge) }
                itemsIndexed(s.offers) { index, offer -> OfferRow(offer, best = index == 0) }
                item {
                    Text(
                        "Liens partenaires : nous pouvons être rémunérés si vous achetez. " +
                            "Le classement repose uniquement sur le prix total, livraison comprise.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun OfferRow(p: PricedOffer, best: Boolean) {
    val uri = LocalUriHandler.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(p.offer.merchant, fontWeight = if (best) FontWeight.Bold else FontWeight.Normal)
            Text(
                when {
                    !p.shippingKnown -> "Livraison à vérifier chez le marchand"
                    p.shippingCents == 0L -> "Livraison offerte"
                    else -> "dont livraison ${p.shippingCents.asEuros()}"
                },
                style = MaterialTheme.typography.bodySmall,
            )
            p.offer.promoCode?.let { Text("Code ${it} appliqué", style = MaterialTheme.typography.bodySmall) }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(p.totalCents.asEuros(), style = MaterialTheme.typography.titleMedium)
            Button(onClick = { uri.openUri(p.offer.trackedUrl) }) { Text("Voir l'offre") }
        }
    }
}
