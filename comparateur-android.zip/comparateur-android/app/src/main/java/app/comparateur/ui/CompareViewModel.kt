package app.comparateur.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.comparateur.data.ComparatorApi
import app.comparateur.domain.PricedOffer
import app.comparateur.domain.rankByTotal
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface UiState {
    data object Idle : UiState
    data object Loading : UiState
    data class Success(val title: String, val offers: List<PricedOffer>) : UiState
    data class Error(val message: String) : UiState
}

class CompareViewModel(private val api: ComparatorApi) : ViewModel() {
    private val _state = MutableStateFlow<UiState>(UiState.Idle)
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var lastEan: String? = null

    /** Appelé en continu par la caméra : on ignore les répétitions du même code. */
    fun onBarcode(ean: String) {
        if (ean == lastEan) return
        lastEan = ean
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = try {
                val r = api.offers(ean)
                UiState.Success(r.title, r.offers.rankByTotal())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastEan = null // permet de rescanner après une erreur
                UiState.Error("Impossible de charger les prix. Vérifiez votre connexion et rescannez.")
            }
        }
    }
}
