package app.comparateur.data

import app.comparateur.domain.Offer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

@Serializable
data class ProductOffersResponse(
    val ean: String,
    val title: String,
    val imageUrl: String? = null,
    val offers: List<Offer>,
)

interface ComparatorApi {
    /** Le serveur agrège les flux d'affiliation et calcule livraison + promos par pays. */
    @GET("v1/products/{ean}/offers")
    suspend fun offers(
        @Path("ean") ean: String,
        @Query("country") country: String = "FR",
        @Query("postal") postal: String? = null,
    ): ProductOffersResponse

    companion object {
        fun create(baseUrl: String): ComparatorApi = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(
                Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType())
            )
            .build()
            .create(ComparatorApi::class.java)
    }
}
